# mymessages-android

android app of MyMessages project

![image](https://files.virgool.io/upload/users/608/posts/oy0jvw2nyuzc/klkvcrirajxo.png)

[Details in my Blog](http://farzad119.ir/?p=127)