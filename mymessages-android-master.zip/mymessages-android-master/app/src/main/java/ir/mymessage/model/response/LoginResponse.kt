package ir.mymessage.model.response

import ir.mymessage.model.remote.User

class LoginResponse {
    var user: User? = null
    var status: Boolean? = null
}
