package ir.mymessage.model.response

class SendMessageResponse {
    var data: Data? = null
    var status: String? = null
}
