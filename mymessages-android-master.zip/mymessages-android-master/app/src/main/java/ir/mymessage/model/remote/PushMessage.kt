package ir.mymessage.model.remote

class PushMessage {
    var friendId: String? = null
    var message: String? = null
    var title: String? = null
    var userId: String? = null
}