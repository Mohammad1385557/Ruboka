package ir.mymessage.model.response

class Data {
    var friendId: String? = null
    var updatedAt: String? = null
    var userId: String? = null
    var toFriendUserId: String? = null
    var nickname: String? = null
    var createdAt: String? = null
    var id: Int = 0
    var content: String? = null
}
