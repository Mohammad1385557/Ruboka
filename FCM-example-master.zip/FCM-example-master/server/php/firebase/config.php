<?php
define("DB_HOST", "localhost");
 define("DB_USER", "*******");
 define("DB_PASSWORD", "*******");
 define("DB_NAME", "*******");

define("SERVER_KEY", "your server key (copy from your google consol");
?>