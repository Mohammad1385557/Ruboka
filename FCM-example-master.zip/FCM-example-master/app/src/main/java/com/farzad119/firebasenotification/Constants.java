package com.farzad119.firebasenotification;

public class Constants {
	public static final String SERVAER = "http://yourServer.ir/";
    public static final String PATH_TO_SERVER_IMAGE_UPLOAD = SERVAER+"token.php";
    public static final String TOKEN_TO_SERVER = "server_token";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
}